module.exports = {
  printWidth: 100,
  singleQuote: true,

  // https://github.com/tailwindlabs/prettier-plugin-tailwindcss
  plugins: [require('prettier-plugin-tailwindcss')],
};
